import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Upload, FileText, AlertCircle } from "lucide-react";
import {
  extractTextFromPDF,
  extractTextFromDOCX,
  extractResumeFields,
  validateResumeData,
} from "@/lib/resumeExtractor";
import { ResumeData } from "@shared/api";

interface ResumeUploadProps {
  onComplete: (data: ResumeData) => void;
}

export default function ResumeUpload({ onComplete }: ResumeUploadProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);

  const handleFileChange = async (file: File) => {
    setFile(file);
    setError("");
    setIsLoading(true);

    try {
      const fileType = file.type;

      let text = "";
      if (fileType === "application/pdf") {
        text = await extractTextFromPDF(file);
      } else if (
        fileType ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        fileType === "application/msword"
      ) {
        text = await extractTextFromDOCX(file);
      } else {
        throw new Error("Please upload a PDF or DOCX file");
      }

      const extractedData = extractResumeFields(text);
      const validation = validateResumeData(extractedData);

      const resumeData: ResumeData = {
        name: extractedData.name || "",
        email: extractedData.email || "",
        phone: extractedData.phone || "",
        rawText: text,
      };

      onComplete(resumeData);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to process resume"
      );
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-foreground mb-2">
          Start Your Interview
        </h1>
        <p className="text-lg text-muted-foreground">
          Upload your resume to get started. We'll extract your information and
          begin the interview process.
        </p>
      </div>

      <div className="bg-card rounded-xl border border-border p-12 mb-8">
        <label
          htmlFor="resume-upload"
          className={`block cursor-pointer transition-all ${
            isLoading ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <div className="flex flex-col items-center justify-center gap-4 py-12">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary to-accent rounded-lg blur opacity-25"></div>
              <div className="relative w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Upload className="w-8 h-8 text-white" />
              </div>
            </div>

            <div className="text-center">
              <p className="text-lg font-semibold text-foreground mb-1">
                {file ? file.name : "Upload your resume"}
              </p>
              <p className="text-sm text-muted-foreground">
                {file ? "Click to change file" : "PDF or DOCX (up to 10MB)"}
              </p>
            </div>
          </div>

          <input
            id="resume-upload"
            type="file"
            accept=".pdf,.docx,.doc"
            onChange={(e) => {
              const selectedFile = e.target.files?.[0];
              if (selectedFile) {
                handleFileChange(selectedFile);
              }
            }}
            disabled={isLoading}
            className="hidden"
          />
        </label>
      </div>

      {error && (
        <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 mb-8 flex gap-3">
          <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-destructive">Error</p>
            <p className="text-sm text-destructive/80">{error}</p>
          </div>
        </div>
      )}

      <div className="bg-secondary rounded-lg p-6">
        <div className="flex gap-3 mb-3">
          <FileText className="w-5 h-5 text-primary flex-shrink-0" />
          <div>
            <p className="font-semibold text-foreground">Supported formats</p>
            <p className="text-sm text-muted-foreground">
              PDF and DOCX files are supported. We'll automatically extract your
              name, email, and phone number from your resume.
            </p>
          </div>
        </div>
      </div>

      {isLoading && (
        <div className="mt-8 text-center">
          <div className="inline-block">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
          <p className="mt-4 text-muted-foreground">Processing your resume...</p>
        </div>
      )}
    </div>
  );
}
