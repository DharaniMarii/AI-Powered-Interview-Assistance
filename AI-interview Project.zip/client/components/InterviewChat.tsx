import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ResumeData, ChatMessage } from "@shared/api";
import { useInterviewState } from "@/hooks/useInterviewState";
import { Candidate } from "@shared/api";
import {
  Send,
  Pause,
  Play,
  Volume2,
  Clock,
  AlertCircle,
} from "lucide-react";

interface InterviewChatProps {
  resumeData: ResumeData;
  onComplete: () => void;
}

export default function InterviewChat({
  resumeData,
  onComplete,
}: InterviewChatProps) {
  const {
    addCandidate,
    createSession,
    currentSession,
    currentSessionId,
    addChatMessage,
    submitAnswer,
    completeInterview,
    pauseSession,
    resumeSession,
  } = useInterviewState();

  const [answer, setAnswer] = useState("");
  const [timeLeft, setTimeLeft] = useState(0);
  const [isAnswering, setIsAnswering] = useState(false);
  const [sessionId, setSessionId] = useState<string>("");
  const [isInitialized, setIsInitialized] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize session
  useEffect(() => {
    if (!isInitialized && !sessionId && currentSessionId) {
      setSessionId(currentSessionId);
      setIsInitialized(true);
    } else if (!isInitialized && !sessionId && !currentSessionId) {
      const candidate: Candidate = {
        id: `candidate_${Date.now()}_${Math.random()}`,
        resumeData,
        createdAt: Date.now(),
        interviewCompleted: false,
        finalScore: 0,
        summary: "",
      };

      addCandidate(candidate);
      const newSessionId = createSession(candidate.id);
      setSessionId(newSessionId);
      setIsInitialized(true);
    }
  }, [isInitialized, sessionId, currentSessionId, addCandidate, createSession, resumeData]);

  // Load current session and add first message
  useEffect(() => {
    if (sessionId && currentSession && currentSession.chatHistory.length === 0) {
      const welcomeMessage: ChatMessage = {
        id: `msg_${Date.now()}`,
        role: "assistant",
        content: `Hello ${resumeData.name}! I'm your AI interviewer. We'll go through 6 questions total: 2 easy, 2 medium, and 2 hard. Each question has a time limit. Let's start!`,
        timestamp: Date.now(),
        type: "text",
      };

      addChatMessage(welcomeMessage);

      // Add first question
      setTimeout(() => {
        if (currentSession && currentSession.questions.length > 0) {
          const firstQuestion = currentSession.questions[0];
          const questionMessage: ChatMessage = {
            id: `msg_${Date.now()}_q`,
            role: "assistant",
            content: `Question 1 (${firstQuestion.difficulty.toUpperCase()}): ${firstQuestion.text}`,
            timestamp: Date.now(),
            type: "question",
          };
          addChatMessage(questionMessage);
          setTimeLeft(firstQuestion.timeLimit);
          setIsAnswering(true);
        }
      }, 500);
    }
  }, [sessionId, currentSession, addChatMessage, resumeData.name]);

  // Timer
  useEffect(() => {
    if (isAnswering && timeLeft > 0) {
      timerIntervalRef.current = setTimeout(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (isAnswering && timeLeft === 0 && answer === "") {
      // Auto-submit empty answer when time runs out
      handleSubmitAnswer();
    }

    return () => {
      if (timerIntervalRef.current) clearTimeout(timerIntervalRef.current);
    };
  }, [timeLeft, isAnswering, answer]);

  // Auto-scroll to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [currentSession?.chatHistory]);

  const handleSubmitAnswer = () => {
    if (!currentSession) return;

    const userMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      role: "user",
      content: answer || "(No answer provided)",
      timestamp: Date.now(),
      type: "text",
    };

    addChatMessage(userMessage);
    submitAnswer(answer);

    setAnswer("");
    setIsAnswering(false);

    // Load next question if available
    const nextQuestion =
      currentSession.questions[currentSession.currentQuestionIndex + 1];

    if (nextQuestion) {
      setTimeout(() => {
        const questionMessage: ChatMessage = {
          id: `msg_${Date.now()}_q`,
          role: "assistant",
          content: `Question ${nextQuestion.number} (${nextQuestion.difficulty.toUpperCase()}): ${nextQuestion.text}`,
          timestamp: Date.now(),
          type: "question",
        };

        addChatMessage(questionMessage);
        setTimeLeft(nextQuestion.timeLimit);
        setIsAnswering(true);
      }, 1000);
    } else {
      // Interview complete
      setTimeout(() => {
        const result = completeInterview();
        if (result) {
          const summaryMessage: ChatMessage = {
            id: `msg_${Date.now()}_summary`,
            role: "assistant",
            content: `Interview Complete! Your final score: ${result.finalScore}/10\n\n${result.summary}`,
            timestamp: Date.now(),
            type: "result",
          };

          addChatMessage(summaryMessage);
          onComplete();
        }
      }, 1000);
    }
  };

  if (!currentSession) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const currentQuestion =
    currentSession.questions[currentSession.currentQuestionIndex];
  const questionsAnswered = currentSession.answers.length;
  const totalQuestions = currentSession.questions.length;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-lg font-semibold text-foreground">
            Question {questionsAnswered + 1} of {totalQuestions}
          </h2>
          <div className="text-sm text-muted-foreground">
            {questionsAnswered}/{totalQuestions} answered
          </div>
        </div>
        <div className="w-full bg-secondary rounded-full h-2">
          <div
            className="bg-gradient-to-r from-primary to-accent h-2 rounded-full transition-all"
            style={{
              width: `${((questionsAnswered) / totalQuestions) * 100}%`,
            }}
          ></div>
        </div>
      </div>

      {/* Chat Area */}
      <Card className="mb-6 h-[500px] overflow-y-auto p-6 flex flex-col">
        <div className="flex-1 overflow-y-auto mb-4">
          {currentSession.chatHistory.map((msg) => (
            <div
              key={msg.id}
              className={`mb-4 flex ${
                msg.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-br-none"
                    : msg.type === "result"
                      ? "bg-green-100 dark:bg-green-900/20 text-foreground border border-green-200 dark:border-green-800"
                      : "bg-secondary text-foreground rounded-bl-none"
                }`}
              >
                <p className="text-sm whitespace-pre-wrap break-words">
                  {msg.content}
                </p>
              </div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
      </Card>

      {/* Timer and Input Area */}
      {isAnswering && currentQuestion && (
        <div className="space-y-4">
          {/* Timer */}
          <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              <span className="font-semibold text-foreground">
                Time remaining: {timeLeft}s
              </span>
            </div>
            <div
              className={`h-2 w-32 rounded-full overflow-hidden ${
                timeLeft < 10 ? "bg-destructive/20" : "bg-muted"
              }`}
            >
              <div
                className={`h-full transition-all ${
                  timeLeft < 10 ? "bg-destructive" : "bg-primary"
                }`}
                style={{
                  width: `${(timeLeft / currentQuestion.timeLimit) * 100}%`,
                }}
              ></div>
            </div>
          </div>

          {/* Answer Input */}
          <div className="flex gap-2">
            <textarea
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              placeholder="Type your answer here..."
              className="flex-1 px-4 py-3 rounded-lg border border-border bg-secondary focus:outline-none focus:ring-2 focus:ring-primary resize-none"
              rows={4}
            />
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmitAnswer}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-3 text-lg"
          >
            <Send className="w-4 h-4 mr-2" />
            Submit Answer
          </Button>
        </div>
      )}

      {!isAnswering && questionsAnswered < totalQuestions && (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading next question...</p>
        </div>
      )}
    </div>
  );
}
