import { useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useInterviewState } from "@/hooks/useInterviewState";
import { Candidate } from "@shared/api";
import { Search, Trophy, User, TrendingUp, Mail, Phone } from "lucide-react";

interface CandidateListProps {
  onSelectCandidate: (candidate: Candidate) => void;
}

type SortBy = "score" | "name" | "date";

export default function CandidateList({ onSelectCandidate }: CandidateListProps) {
  const { candidates } = useInterviewState();
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState<SortBy>("score");
  const [filterByCompleted, setFilterByCompleted] = useState<"all" | "completed" | "pending">("all");

  const filteredAndSorted = useMemo(() => {
    let filtered = candidates;

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(
        (c) =>
          c.resumeData.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          c.resumeData.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
          c.resumeData.phone.includes(searchTerm)
      );
    }

    // Filter by completion status
    if (filterByCompleted === "completed") {
      filtered = filtered.filter((c) => c.interviewCompleted);
    } else if (filterByCompleted === "pending") {
      filtered = filtered.filter((c) => !c.interviewCompleted);
    }

    // Sort
    const sorted = [...filtered].sort((a, b) => {
      if (sortBy === "score") {
        return b.finalScore - a.finalScore;
      } else if (sortBy === "name") {
        return a.resumeData.name.localeCompare(b.resumeData.name);
      } else if (sortBy === "date") {
        return b.createdAt - a.createdAt;
      }
      return 0;
    });

    return sorted;
  }, [candidates, searchTerm, sortBy, filterByCompleted]);

  const completedCount = candidates.filter((c) => c.interviewCompleted).length;
  const totalCount = candidates.length;

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-green-600 dark:text-green-400";
    if (score >= 6) return "text-blue-600 dark:text-blue-400";
    if (score >= 4) return "text-yellow-600 dark:text-yellow-400";
    return "text-destructive";
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 8) return "bg-green-100 dark:bg-green-900/20";
    if (score >= 6) return "bg-blue-100 dark:bg-blue-900/20";
    if (score >= 4) return "bg-yellow-100 dark:bg-yellow-900/20";
    return "bg-destructive/10";
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-foreground mb-2">
          Interview Dashboard
        </h1>
        <p className="text-lg text-muted-foreground">
          Review candidates and their interview results
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total Candidates</p>
              <p className="text-3xl font-bold text-foreground">{totalCount}</p>
            </div>
            <User className="w-10 h-10 text-primary opacity-20" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Interviews Completed</p>
              <p className="text-3xl font-bold text-foreground">{completedCount}</p>
            </div>
            <Trophy className="w-10 h-10 text-accent opacity-20" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Average Score</p>
              <p className="text-3xl font-bold text-foreground">
                {completedCount > 0
                  ? (
                      candidates
                        .filter((c) => c.interviewCompleted)
                        .reduce((sum, c) => sum + c.finalScore, 0) / completedCount
                    ).toFixed(1)
                  : "—"}
              </p>
            </div>
            <TrendingUp className="w-10 h-10 text-primary opacity-20" />
          </div>
        </Card>
      </div>

      {/* Filters and Search */}
      <div className="mb-6 space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search by name, email, or phone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-lg border border-border bg-secondary focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>

        {/* Filters and Sort */}
        <div className="flex flex-col sm:flex-row gap-4">
          <select
            value={filterByCompleted}
            onChange={(e) => setFilterByCompleted(e.target.value as any)}
            className="px-4 py-2 rounded-lg border border-border bg-secondary focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="all">All Candidates</option>
            <option value="completed">Completed</option>
            <option value="pending">Pending</option>
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as SortBy)}
            className="px-4 py-2 rounded-lg border border-border bg-secondary focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="score">Sort by Score (High to Low)</option>
            <option value="name">Sort by Name (A to Z)</option>
            <option value="date">Sort by Date (Newest)</option>
          </select>
        </div>
      </div>

      {/* Candidates List */}
      {filteredAndSorted.length === 0 ? (
        <Card className="p-12 text-center">
          <User className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-lg text-muted-foreground">
            {searchTerm
              ? "No candidates found matching your search"
              : "No candidates yet. Start the interviewee tab to add candidates."}
          </p>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredAndSorted.map((candidate) => (
            <Card
              key={candidate.id}
              className="p-6 hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => onSelectCandidate(candidate)}
            >
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                {/* Left Side - Candidate Info */}
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-foreground mb-1">
                    {candidate.resumeData.name}
                  </h3>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      {candidate.resumeData.email}
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      {candidate.resumeData.phone}
                    </div>
                  </div>
                </div>

                {/* Right Side - Score and Status */}
                <div className="flex items-center gap-6">
                  {candidate.interviewCompleted ? (
                    <div className={`text-right ${getScoreColor(candidate.finalScore)}`}>
                      <p className="text-4xl font-bold">
                        {candidate.finalScore.toFixed(1)}
                      </p>
                      <p className="text-xs font-semibold text-muted-foreground">
                        out of 10
                      </p>
                    </div>
                  ) : (
                    <div className="text-right">
                      <p className="text-sm font-semibold text-yellow-600 dark:text-yellow-400">
                        Pending
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Interview not started
                      </p>
                    </div>
                  )}

                  <Button
                    variant="outline"
                    className="hidden sm:flex"
                    onClick={() => onSelectCandidate(candidate)}
                  >
                    View Details
                  </Button>
                </div>
              </div>

              {candidate.interviewCompleted && candidate.summary && (
                <p className="mt-4 text-sm text-muted-foreground line-clamp-2">
                  {candidate.summary}
                </p>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
