import { cn } from "@/lib/utils";
import { MessageSquare, BarChart3 } from "lucide-react";

interface HeaderProps {
  activeTab: "interviewee" | "interviewer";
  setActiveTab: (tab: "interviewee" | "interviewer") => void;
}

export default function Header({ activeTab, setActiveTab }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">C</span>
            </div>
            <h1 className="text-xl font-bold text-foreground">Crisp</h1>
            <span className="text-xs text-muted-foreground ml-2 px-2 py-1 bg-secondary rounded">
              AI Interview
            </span>
          </div>

          {/* Tabs */}
          <nav className="hidden sm:flex gap-2">
            <button
              onClick={() => setActiveTab("interviewee")}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg transition-colors font-medium",
                activeTab === "interviewee"
                  ? "bg-primary text-primary-foreground"
                  : "text-foreground hover:bg-secondary"
              )}
            >
              <MessageSquare className="w-4 h-4" />
              Interviewee
            </button>
            <button
              onClick={() => setActiveTab("interviewer")}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg transition-colors font-medium",
                activeTab === "interviewer"
                  ? "bg-primary text-primary-foreground"
                  : "text-foreground hover:bg-secondary"
              )}
            >
              <BarChart3 className="w-4 h-4" />
              Interviewer
            </button>
          </nav>

          {/* Mobile menu indicator */}
          <div className="sm:hidden flex gap-2">
            <button
              onClick={() => setActiveTab("interviewee")}
              className={cn(
                "p-2 rounded-lg transition-colors",
                activeTab === "interviewee"
                  ? "bg-primary text-primary-foreground"
                  : "text-foreground hover:bg-secondary"
              )}
              title="Interviewee"
            >
              <MessageSquare className="w-4 h-4" />
            </button>
            <button
              onClick={() => setActiveTab("interviewer")}
              className={cn(
                "p-2 rounded-lg transition-colors",
                activeTab === "interviewer"
                  ? "bg-primary text-primary-foreground"
                  : "text-foreground hover:bg-secondary"
              )}
              title="Interviewer"
            >
              <BarChart3 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
