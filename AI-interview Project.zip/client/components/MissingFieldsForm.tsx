import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { validateResumeData } from "@/lib/resumeExtractor";
import { ResumeData } from "@shared/api";
import { AlertCircle, Check } from "lucide-react";

interface MissingFieldsFormProps {
  resumeData: ResumeData;
  onComplete: (data: ResumeData) => void;
}

export default function MissingFieldsForm({
  resumeData,
  onComplete,
}: MissingFieldsFormProps) {
  const [formData, setFormData] = useState<ResumeData>(resumeData);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validation = validateResumeData(formData);

  const handleChange = (field: keyof ResumeData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleSubmit = () => {
    if (!validation.isValid) {
      const newErrors: Record<string, string> = {};
      validation.missingFields.forEach((field) => {
        newErrors[field] = `${field.charAt(0).toUpperCase() + field.slice(1)} is required`;
      });
      setErrors(newErrors);
      return;
    }

    onComplete(formData);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-foreground mb-2">
          Complete Your Profile
        </h1>
        <p className="text-lg text-muted-foreground">
          {validation.missingFields.length > 0
            ? `We need your ${validation.missingFields.join(", ")} to proceed`
            : "Your information looks complete! Ready to start?"}
        </p>
      </div>

      <Card className="p-8 mb-8">
        <div className="space-y-6">
          {/* Name Field */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Full Name
              {!formData.name && <span className="text-destructive ml-1">*</span>}
              {formData.name && (
                <span className="text-green-500 ml-1">✓</span>
              )}
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="John Doe"
              className={`w-full px-4 py-2 rounded-lg border transition-colors ${
                errors.name
                  ? "border-destructive bg-destructive/5 focus:outline-none focus:ring-2 focus:ring-destructive"
                  : "border-border bg-secondary focus:outline-none focus:ring-2 focus:ring-primary"
              }`}
            />
            {errors.name && (
              <p className="text-sm text-destructive mt-1">{errors.name}</p>
            )}
          </div>

          {/* Email Field */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Email
              {!formData.email && <span className="text-destructive ml-1">*</span>}
              {formData.email && (
                <span className="text-green-500 ml-1">✓</span>
              )}
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => handleChange("email", e.target.value)}
              placeholder="john@example.com"
              className={`w-full px-4 py-2 rounded-lg border transition-colors ${
                errors.email
                  ? "border-destructive bg-destructive/5 focus:outline-none focus:ring-2 focus:ring-destructive"
                  : "border-border bg-secondary focus:outline-none focus:ring-2 focus:ring-primary"
              }`}
            />
            {errors.email && (
              <p className="text-sm text-destructive mt-1">{errors.email}</p>
            )}
          </div>

          {/* Phone Field */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Phone Number
              {!formData.phone && <span className="text-destructive ml-1">*</span>}
              {formData.phone && (
                <span className="text-green-500 ml-1">✓</span>
              )}
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => handleChange("phone", e.target.value)}
              placeholder="(123) 456-7890"
              className={`w-full px-4 py-2 rounded-lg border transition-colors ${
                errors.phone
                  ? "border-destructive bg-destructive/5 focus:outline-none focus:ring-2 focus:ring-destructive"
                  : "border-border bg-secondary focus:outline-none focus:ring-2 focus:ring-primary"
              }`}
            />
            {errors.phone && (
              <p className="text-sm text-destructive mt-1">{errors.phone}</p>
            )}
          </div>
        </div>

        {/* Summary Card */}
        {validation.isValid && (
          <div className="mt-8 p-4 bg-green-500/10 border border-green-500/20 rounded-lg flex gap-3">
            <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-green-900 dark:text-green-100">
                All set!
              </p>
              <p className="text-sm text-green-800 dark:text-green-200">
                Your profile is complete. Click "Start Interview" to begin.
              </p>
            </div>
          </div>
        )}
      </Card>

      <div className="flex gap-3">
        <Button
          onClick={handleSubmit}
          className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 py-6 text-lg"
          disabled={!validation.isValid}
        >
          Start Interview
        </Button>
      </div>
    </div>
  );
}
