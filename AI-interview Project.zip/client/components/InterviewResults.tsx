import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ResumeData } from "@shared/api";
import { useInterviewState } from "@/hooks/useInterviewState";
import { Award, BarChart3, Home } from "lucide-react";

interface InterviewResultsProps {
  resumeData: ResumeData;
}

export default function InterviewResults({
  resumeData,
}: InterviewResultsProps) {
  const { candidates, currentSession } = useInterviewState();
  const [finalScore, setFinalScore] = useState(0);
  const [summary, setSummary] = useState("");

  useEffect(() => {
    if (currentSession) {
      setFinalScore(currentSession.totalScore);
      setSummary(currentSession.summary);
    }
  }, [currentSession]);

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-green-600 dark:text-green-400";
    if (score >= 6) return "text-blue-600 dark:text-blue-400";
    if (score >= 4) return "text-yellow-600 dark:text-yellow-400";
    return "text-destructive";
  };

  const getScoreBg = (score: number) => {
    if (score >= 8) return "bg-green-100 dark:bg-green-900/20";
    if (score >= 6) return "bg-blue-100 dark:bg-blue-900/20";
    if (score >= 4) return "bg-yellow-100 dark:bg-yellow-900/20";
    return "bg-destructive/10";
  };

  const getScoreLabel = (score: number) => {
    if (score >= 8) return "Excellent";
    if (score >= 6) return "Good";
    if (score >= 4) return "Fair";
    return "Needs Improvement";
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-foreground mb-2">
          Interview Complete!
        </h1>
        <p className="text-lg text-muted-foreground">
          Thank you for completing the interview, {resumeData.name}
        </p>
      </div>

      {/* Score Card */}
      <Card className={`${getScoreBg(finalScore)} p-12 mb-8 border-2`}>
        <div className="text-center mb-8">
          <div className={`text-6xl font-bold mb-4 ${getScoreColor(finalScore)}`}>
            {finalScore.toFixed(1)}/10
          </div>
          <p className={`text-2xl font-semibold ${getScoreColor(finalScore)}`}>
            {getScoreLabel(finalScore)}
          </p>
        </div>

        <div className="space-y-4">
          {currentSession?.answers && currentSession.answers.length > 0 && (
            <>
              <h3 className="font-semibold text-foreground text-center mb-4">
                Question Breakdown
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Easy Questions */}
                <div className="bg-white dark:bg-card rounded-lg p-4">
                  <p className="text-sm font-semibold text-muted-foreground mb-2">
                    Easy Questions
                  </p>
                  {currentSession.answers
                    .filter((a) => a.difficulty === "easy")
                    .map((a) => (
                      <div key={a.questionId} className="mb-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-foreground">
                            Q{a.questionNumber}
                          </span>
                          <span className="font-bold text-primary">
                            {a.score}/10
                          </span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-1.5 mt-1">
                          <div
                            className="bg-primary h-1.5 rounded-full"
                            style={{ width: `${(a.score / 10) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                </div>

                {/* Medium Questions */}
                <div className="bg-white dark:bg-card rounded-lg p-4">
                  <p className="text-sm font-semibold text-muted-foreground mb-2">
                    Medium Questions
                  </p>
                  {currentSession.answers
                    .filter((a) => a.difficulty === "medium")
                    .map((a) => (
                      <div key={a.questionId} className="mb-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-foreground">
                            Q{a.questionNumber}
                          </span>
                          <span className="font-bold text-primary">
                            {a.score}/10
                          </span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-1.5 mt-1">
                          <div
                            className="bg-primary h-1.5 rounded-full"
                            style={{ width: `${(a.score / 10) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                </div>

                {/* Hard Questions */}
                <div className="bg-white dark:bg-card rounded-lg p-4">
                  <p className="text-sm font-semibold text-muted-foreground mb-2">
                    Hard Questions
                  </p>
                  {currentSession.answers
                    .filter((a) => a.difficulty === "hard")
                    .map((a) => (
                      <div key={a.questionId} className="mb-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-foreground">
                            Q{a.questionNumber}
                          </span>
                          <span className="font-bold text-primary">
                            {a.score}/10
                          </span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-1.5 mt-1">
                          <div
                            className="bg-primary h-1.5 rounded-full"
                            style={{ width: `${(a.score / 10) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </>
          )}
        </div>
      </Card>

      {/* Summary */}
      {summary && (
        <Card className="p-8 mb-8">
          <h2 className="text-xl font-bold text-foreground mb-4">
            Interview Summary
          </h2>
          <p className="text-foreground leading-relaxed whitespace-pre-wrap">
            {summary}
          </p>
        </Card>
      )}

      {/* Detailed Feedback */}
      {currentSession?.answers && currentSession.answers.length > 0 && (
        <Card className="p-8 mb-8">
          <h2 className="text-xl font-bold text-foreground mb-6">
            Detailed Feedback
          </h2>
          <div className="space-y-6">
            {currentSession.answers.map((answer) => (
              <div
                key={answer.questionId}
                className="border border-border rounded-lg p-6"
              >
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <p className="font-semibold text-foreground">
                      Question {answer.questionNumber} ({answer.difficulty.toUpperCase()})
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Time: {answer.timeTaken}s / {answer.timeLimit}s
                    </p>
                  </div>
                  <div className="text-right">
                    <p className={`text-2xl font-bold ${getScoreColor(answer.score)}`}>
                      {answer.score}/10
                    </p>
                  </div>
                </div>

                <div className="mb-4 p-3 bg-secondary rounded-lg">
                  <p className="text-sm text-foreground">{answer.text || "(No answer provided)"}</p>
                </div>

                <div className="p-3 bg-accent/10 rounded-lg">
                  <p className="text-sm font-semibold text-accent mb-1">Feedback:</p>
                  <p className="text-sm text-foreground">{answer.feedback}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex gap-4">
        <Button
          onClick={() => window.location.reload()}
          className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 py-6 text-lg"
        >
          <Home className="w-4 h-4 mr-2" />
          Start New Interview
        </Button>
        <Button
          variant="outline"
          className="flex-1 py-6 text-lg"
          onClick={() => {
            window.location.href = "#";
          }}
        >
          <BarChart3 className="w-4 h-4 mr-2" />
          View Dashboard
        </Button>
      </div>
    </div>
  );
}
