import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ResumeData } from "@shared/api";
import { Code, Check } from "lucide-react";

interface LanguageSelectionProps {
  resumeData: ResumeData;
  detectedLanguages: string[];
  onComplete: (data: ResumeData, selectedLanguage: string) => void;
}

const PROGRAMMING_LANGUAGES = [
  { id: "javascript", name: "JavaScript", icon: "JS" },
  { id: "python", name: "Python", icon: "PY" },
  { id: "java", name: "Java", icon: "JA" },
  { id: "cpp", name: "C++", icon: "C++" },
  { id: "csharp", name: "C#", icon: "C#" },
  { id: "typescript", name: "TypeScript", icon: "TS" },
  { id: "go", name: "Go", icon: "GO" },
  { id: "rust", name: "Rust", icon: "RS" },
  { id: "php", name: "PHP", icon: "PHP" },
  { id: "swift", name: "Swift", icon: "SW" },
  { id: "kotlin", name: "Kotlin", icon: "KT" },
  { id: "ruby", name: "Ruby", icon: "RB" },
];

export default function LanguageSelection({
  resumeData,
  detectedLanguages,
  onComplete,
}: LanguageSelectionProps) {
  const [selectedLanguage, setSelectedLanguage] = useState<string>("");

  const handleSubmit = () => {
    if (selectedLanguage) {
      onComplete(resumeData, selectedLanguage);
    }
  };

  const isDetected = (langId: string) => {
    return detectedLanguages.some(detected => 
      detected.toLowerCase().includes(langId) || 
      langId.includes(detected.toLowerCase())
    );
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-foreground mb-2">
          Choose Your Programming Language
        </h1>
        <p className="text-lg text-muted-foreground">
          Select the programming language for your technical interview
        </p>
        {detectedLanguages.length > 0 && (
          <p className="text-sm text-primary mt-2">
            Detected from resume: {detectedLanguages.join(", ")}
          </p>
        )}
      </div>

      <Card className="p-8 mb-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {PROGRAMMING_LANGUAGES.map((lang) => (
            <button
              key={lang.id}
              onClick={() => setSelectedLanguage(lang.id)}
              className={`relative p-6 rounded-lg border-2 transition-all hover:scale-105 ${
                selectedLanguage === lang.id
                  ? "border-primary bg-primary/10 shadow-lg"
                  : "border-border bg-card hover:border-primary/50"
              }`}
            >
              {/* Badge for detected languages */}
              {isDetected(lang.id) && (
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                  <Check className="w-3 h-3 text-white" />
                </div>
              )}

              <div className="flex flex-col items-center gap-3">
                <div
                  className={`w-12 h-12 rounded-lg flex items-center justify-center text-xs font-bold ${
                    selectedLanguage === lang.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-foreground"
                  }`}
                >
                  {lang.icon}
                </div>
                <p
                  className={`font-semibold ${
                    selectedLanguage === lang.id
                      ? "text-primary"
                      : "text-foreground"
                  }`}
                >
                  {lang.name}
                </p>
              </div>

              {selectedLanguage === lang.id && (
                <div className="absolute inset-0 border-2 border-primary rounded-lg bg-primary/5"></div>
              )}
            </button>
          ))}
        </div>
      </Card>

      {selectedLanguage && (
        <div className="mb-8 p-4 bg-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-center gap-3">
            <Code className="w-5 h-5 text-primary" />
            <div>
              <p className="font-semibold text-primary">
                {PROGRAMMING_LANGUAGES.find(l => l.id === selectedLanguage)?.name} Selected
              </p>
              <p className="text-sm text-primary/80">
                You'll receive coding questions tailored for this language
              </p>
            </div>
          </div>
        </div>
      )}

      <Button
        onClick={handleSubmit}
        disabled={!selectedLanguage}
        className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-6 text-lg"
      >
        Start Coding Interview
      </Button>
    </div>
  );
}
