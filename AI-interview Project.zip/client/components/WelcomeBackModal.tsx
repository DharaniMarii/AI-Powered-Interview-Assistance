import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

interface WelcomeBackModalProps {
  onResume: () => void;
  onStartNew: () => void;
}

export default function WelcomeBackModal({
  onResume,
  onStartNew,
}: WelcomeBackModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-card rounded-xl shadow-2xl p-8 max-w-md w-full mx-4">
        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-accent/10 mx-auto mb-4">
          <AlertCircle className="w-6 h-6 text-accent" />
        </div>

        <h2 className="text-2xl font-bold text-center text-foreground mb-2">
          Welcome Back!
        </h2>

        <p className="text-center text-muted-foreground mb-6">
          We detected that you have an ongoing interview session. Would you like
          to resume it or start a new one?
        </p>

        <div className="space-y-3">
          <Button
            onClick={onResume}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
            size="lg"
          >
            Resume Session
          </Button>
          <Button
            onClick={onStartNew}
            variant="outline"
            className="w-full"
            size="lg"
          >
            Start New Interview
          </Button>
        </div>
      </div>
    </div>
  );
}
