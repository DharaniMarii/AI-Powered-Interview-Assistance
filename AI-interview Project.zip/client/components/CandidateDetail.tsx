import { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useInterviewState } from "@/hooks/useInterviewState";
import { Candidate } from "@shared/api";
import { ArrowLeft, Clock, TrendingUp, MessageSquare } from "lucide-react";

interface CandidateDetailProps {
  candidate: Candidate;
  onBack: () => void;
}

export default function CandidateDetail({
  candidate,
  onBack,
}: CandidateDetailProps) {
  const { sessions } = useInterviewState();

  const candidateSession = useMemo(() => {
    return sessions.find((s) => s.candidateId === candidate.id);
  }, [sessions, candidate.id]);

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-green-600 dark:text-green-400";
    if (score >= 6) return "text-blue-600 dark:text-blue-400";
    if (score >= 4) return "text-yellow-600 dark:text-yellow-400";
    return "text-destructive";
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 8) return "bg-green-100 dark:bg-green-900/20";
    if (score >= 6) return "bg-blue-100 dark:bg-blue-900/20";
    if (score >= 4) return "bg-yellow-100 dark:bg-yellow-900/20";
    return "bg-destructive/10";
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Header */}
      <Button
        variant="ghost"
        onClick={onBack}
        className="mb-6 -ml-2"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Candidates
      </Button>

      {/* Candidate Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-foreground mb-2">
          {candidate.resumeData.name}
        </h1>
        <div className="flex flex-col sm:flex-row sm:items-center gap-4 text-muted-foreground">
          <span>{candidate.resumeData.email}</span>
          <span className="hidden sm:inline">•</span>
          <span>{candidate.resumeData.phone}</span>
        </div>
      </div>

      {!candidate.interviewCompleted ? (
        <Card className="p-12 text-center mb-8">
          <MessageSquare className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-lg text-muted-foreground">
            This candidate has not completed their interview yet.
          </p>
        </Card>
      ) : (
        <>
          {/* Score Section */}
          <Card className={`${getScoreBgColor(candidate.finalScore)} p-8 mb-8 border-2`}>
            <div className="text-center mb-8">
              <div className={`text-6xl font-bold mb-4 ${getScoreColor(candidate.finalScore)}`}>
                {candidate.finalScore.toFixed(1)}/10
              </div>
              <p className="text-muted-foreground">
                {candidate.interviewCompleted ? "Final Interview Score" : "Pending"}
              </p>
            </div>

            {candidateSession && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Questions Answered
                  </p>
                  <p className="text-2xl font-bold text-foreground">
                    {candidateSession.answers.length} / {candidateSession.questions.length}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Interview Duration
                  </p>
                  <p className="text-2xl font-bold text-foreground">
                    {candidateSession.completedAt
                      ? Math.round((candidateSession.completedAt - candidateSession.startedAt) / 1000 / 60)
                      : "—"}{" "}
                    min
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Average Time per Q
                  </p>
                  <p className="text-2xl font-bold text-foreground">
                    {candidateSession.answers.length > 0
                      ? Math.round(
                          candidateSession.answers.reduce((sum, a) => sum + a.timeTaken, 0) /
                            candidateSession.answers.length
                        )
                      : "—"}
                    s
                  </p>
                </div>
              </div>
            )}
          </Card>

          {/* Summary */}
          {candidate.summary && (
            <Card className="p-8 mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">
                Interview Summary
              </h2>
              <p className="text-foreground leading-relaxed whitespace-pre-wrap">
                {candidate.summary}
              </p>
            </Card>
          )}

          {/* Detailed Answers */}
          {candidateSession && candidateSession.answers.length > 0 && (
            <Card className="p-8 mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-6">
                Question Responses
              </h2>
              <div className="space-y-6">
                {candidateSession.answers.map((answer) => (
                  <div
                    key={answer.questionId}
                    className="border border-border rounded-lg p-6"
                  >
                    {/* Question Header */}
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
                      <div className="flex-1">
                        <p className="font-semibold text-foreground text-lg">
                          Question {answer.questionNumber}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Difficulty:{" "}
                          <span className="font-semibold">
                            {answer.difficulty.toUpperCase()}
                          </span>
                        </p>
                      </div>
                      <div className="text-right">
                        <p className={`text-3xl font-bold ${getScoreColor(answer.score)}`}>
                          {answer.score}/10
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          <Clock className="w-3 h-3 inline mr-1" />
                          {answer.timeTaken}s / {answer.timeLimit}s
                        </p>
                      </div>
                    </div>

                    {/* Candidate's Answer */}
                    <div className="mb-4">
                      <p className="text-sm font-semibold text-muted-foreground mb-2">
                        Candidate's Answer:
                      </p>
                      <div className="bg-secondary rounded-lg p-4 text-sm text-foreground">
                        {answer.text || "(No answer provided)"}
                      </div>
                    </div>

                    {/* AI Feedback */}
                    <div>
                      <p className="text-sm font-semibold text-muted-foreground mb-2">
                        Feedback:
                      </p>
                      <div className="bg-accent/10 rounded-lg p-4 text-sm text-foreground border border-accent/20">
                        {answer.feedback}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Chat History */}
          {candidateSession && candidateSession.chatHistory.length > 0 && (
            <Card className="p-8">
              <h2 className="text-2xl font-bold text-foreground mb-6">
                Chat History
              </h2>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {candidateSession.chatHistory.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-xs px-4 py-2 rounded-lg text-sm ${
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-secondary text-foreground"
                      }`}
                    >
                      {msg.content}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
