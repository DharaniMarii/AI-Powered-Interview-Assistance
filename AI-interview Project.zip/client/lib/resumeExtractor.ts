import { ResumeData } from "@shared/api";

/**
 * Extract text from a PDF file
 * In a production app, use pdfjs-dist or similar library
 */
export async function extractTextFromPDF(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const arrayBuffer = e.target?.result as ArrayBuffer;
        // For demo purposes, convert to text-like representation
        // In production, use proper PDF.js library
        const text = await extractPDFContent(arrayBuffer);
        resolve(text);
      } catch (error) {
        reject(error);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Extract text from a DOCX file
 * In a production app, use docx or similar library
 */
export async function extractTextFromDOCX(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const arrayBuffer = e.target?.result as ArrayBuffer;
        // For demo purposes, convert to text
        // In production, use proper docx parsing library
        const text = await extractDOCXContent(arrayBuffer);
        resolve(text);
      } catch (error) {
        reject(error);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Extract resume data (name, email, phone) from text
 */
export function extractResumeFields(text: string): Partial<ResumeData> {
  const data: Partial<ResumeData> = { rawText: text };

  // Extract name - usually at the top, capitalized
  const nameMatch = text.match(
    /^([A-Z][a-z]+ [A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)/m
  );
  if (nameMatch) {
    data.name = nameMatch[1].trim();
  }

  // Extract email
  const emailMatch = text.match(
    /([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/i
  );
  if (emailMatch) {
    data.email = emailMatch[1];
  }

  // Extract phone - various formats
  const phoneMatch = text.match(
    /(\+?1?\s*)?(\(?\d{3}\)?[\s.-]?)?\d{3}[\s.-]?\d{4}/
  );
  if (phoneMatch) {
    // Clean up phone number
    const cleanPhone = phoneMatch[0].replace(/\D/g, "");
    if (cleanPhone.length >= 10) {
      data.phone = formatPhoneNumber(cleanPhone);
    }
  }

  return data;
}

/**
 * Format phone number to (XXX) XXX-XXXX format
 */
function formatPhoneNumber(digits: string): string {
  const cleaned = digits.replace(/\D/g, "");
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  } else if (cleaned.length === 11 && cleaned[0] === "1") {
    return `(${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
  }
  return cleaned;
}

/**
 * Helper to extract PDF content (simplified for demo)
 */
async function extractPDFContent(arrayBuffer: ArrayBuffer): Promise<string> {
  // In a real app, use pdf.js library
  // For now, return a simulated extraction
  const view = new Uint8Array(arrayBuffer);
  const decoder = new TextDecoder("utf-8");
  let text = decoder.decode(view);

  // Remove non-text content
  text = text.replace(/[^\x00-\x7F\u0080-\u00FF]/g, " ");
  return text;
}

/**
 * Helper to extract DOCX content (simplified for demo)
 */
async function extractDOCXContent(arrayBuffer: ArrayBuffer): Promise<string> {
  // In a real app, use docx library
  // For now, return a simulated extraction
  const view = new Uint8Array(arrayBuffer);
  const decoder = new TextDecoder("utf-8");
  let text = decoder.decode(view);

  // Remove XML and binary content
  text = text.replace(/<[^>]*>/g, " ");
  text = text.replace(/[^\x00-\x7F\u0080-\u00FF]/g, " ");
  return text;
}

/**
 * Validate resume data completeness
 */
export function validateResumeData(data: Partial<ResumeData>): {
  isValid: boolean;
  missingFields: (keyof ResumeData)[];
} {
  const missingFields: (keyof ResumeData)[] = [];

  if (!data.name || data.name.trim() === "") {
    missingFields.push("name");
  }
  if (!data.email || data.email.trim() === "") {
    missingFields.push("email");
  }
  if (!data.phone || data.phone.trim() === "") {
    missingFields.push("phone");
  }

  return {
    isValid: missingFields.length === 0,
    missingFields,
  };
}
