import { Question, Difficulty, Answer } from "@shared/api";

/**
 * Generate coding questions based on selected programming language
 * Structure: 2 Easy, 2 Medium, 2 Hard
 */
export function generateCodingQuestions(language: string): Question[] {
  const questions: Question[] = [];
  let questionNumber = 1;

  const languageConfigs = getCodingQuestionsByLanguage(language);

  // Easy Questions (5 minutes each)
  languageConfigs.easy.forEach((questionData) => {
    questions.push({
      id: `q-${questionNumber}`,
      number: questionNumber,
      difficulty: Difficulty.EASY,
      title: questionData.title,
      description: questionData.description,
      examples: questionData.examples,
      constraints: questionData.constraints,
      timeLimit: 300, // 5 minutes
      language,
    });
    questionNumber++;
  });

  // Medium Questions (8 minutes each)
  languageConfigs.medium.forEach((questionData) => {
    questions.push({
      id: `q-${questionNumber}`,
      number: questionNumber,
      difficulty: Difficulty.MEDIUM,
      title: questionData.title,
      description: questionData.description,
      examples: questionData.examples,
      constraints: questionData.constraints,
      timeLimit: 480, // 8 minutes
      language,
    });
    questionNumber++;
  });

  // Hard Questions (12 minutes each)
  languageConfigs.hard.forEach((questionData) => {
    questions.push({
      id: `q-${questionNumber}`,
      number: questionNumber,
      difficulty: Difficulty.HARD,
      title: questionData.title,
      description: questionData.description,
      examples: questionData.examples,
      constraints: questionData.constraints,
      timeLimit: 720, // 12 minutes
      language,
    });
    questionNumber++;
  });

  return questions;
}

/**
 * Get coding questions by programming language
 */
function getCodingQuestionsByLanguage(language: string) {
  const questionBank = {
    javascript: {
      easy: [
        {
          title: "Reverse String",
          description: "Write a function that reverses a string.",
          examples: [
            "Input: 'hello'\nOutput: 'olleh'",
            "Input: 'JavaScript'\nOutput: 'tpircSavaJ'"
          ],
          constraints: ["1 <= s.length <= 1000"]
        },
        {
          title: "Find Maximum Number",
          description: "Write a function that finds the maximum number in an array.",
          examples: [
            "Input: [1, 3, 2, 8, 5]\nOutput: 8",
            "Input: [-1, -3, -2]\nOutput: -1"
          ],
          constraints: ["1 <= arr.length <= 100"]
        }
      ],
      medium: [
        {
          title: "Two Sum",
          description: "Given an array of integers and a target sum, return indices of two numbers that add up to the target.",
          examples: [
            "Input: nums = [2,7,11,15], target = 9\nOutput: [0,1]",
            "Input: nums = [3,2,4], target = 6\nOutput: [1,2]"
          ],
          constraints: ["2 <= nums.length <= 1000", "Each input has exactly one solution"]
        },
        {
          title: "Palindrome Check",
          description: "Write a function to check if a string is a palindrome (reads the same forwards and backwards).",
          examples: [
            "Input: 'racecar'\nOutput: true",
            "Input: 'hello'\nOutput: false"
          ],
          constraints: ["1 <= s.length <= 1000", "Consider only alphanumeric characters"]
        }
      ],
      hard: [
        {
          title: "Binary Tree Traversal",
          description: "Implement inorder traversal of a binary tree without using recursion.",
          examples: [
            "Input: [1,null,2,3]\nOutput: [1,3,2]"
          ],
          constraints: ["Number of nodes is in range [0, 100]"]
        },
        {
          title: "Merge Intervals",
          description: "Given a collection of intervals, merge all overlapping intervals.",
          examples: [
            "Input: [[1,3],[2,6],[8,10],[15,18]]\nOutput: [[1,6],[8,10],[15,18]]"
          ],
          constraints: ["1 <= intervals.length <= 1000"]
        }
      ]
    },
    python: {
      easy: [
        {
          title: "Reverse List",
          description: "Write a function that reverses a list.",
          examples: [
            "Input: [1, 2, 3, 4, 5]\nOutput: [5, 4, 3, 2, 1]",
            "Input: ['a', 'b', 'c']\nOutput: ['c', 'b', 'a']"
          ],
          constraints: ["0 <= len(lst) <= 1000"]
        },
        {
          title: "Count Vowels",
          description: "Write a function that counts the number of vowels in a string.",
          examples: [
            "Input: 'hello'\nOutput: 2",
            "Input: 'programming'\nOutput: 3"
          ],
          constraints: ["1 <= len(s) <= 1000"]
        }
      ],
      medium: [
        {
          title: "Group Anagrams",
          description: "Given an array of strings, group anagrams together.",
          examples: [
            "Input: ['eat','tea','tan','ate','nat','bat']\nOutput: [['eat','tea','ate'],['tan','nat'],['bat']]"
          ],
          constraints: ["1 <= strs.length <= 100"]
        },
        {
          title: "Valid Parentheses",
          description: "Given a string containing just characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid.",
          examples: [
            "Input: '()'\nOutput: True",
            "Input: '([)]'\nOutput: False"
          ],
          constraints: ["1 <= s.length <= 1000"]
        }
      ],
      hard: [
        {
          title: "Longest Substring Without Repeating Characters",
          description: "Find the length of the longest substring without repeating characters.",
          examples: [
            "Input: 'abcabcbb'\nOutput: 3 (abc)",
            "Input: 'bbbbb'\nOutput: 1 (b)"
          ],
          constraints: ["0 <= s.length <= 50000"]
        },
        {
          title: "Word Ladder",
          description: "Given two words and a dictionary, find the length of shortest transformation sequence.",
          examples: [
            "Input: beginWord = 'hit', endWord = 'cog', wordList = ['hot','dot','dog','lot','log','cog']\nOutput: 5"
          ],
          constraints: ["1 <= beginWord.length <= 10"]
        }
      ]
    },
    java: {
      easy: [
        {
          title: "Array Sum",
          description: "Write a method that calculates the sum of all elements in an integer array.",
          examples: [
            "Input: [1, 2, 3, 4, 5]\nOutput: 15",
            "Input: [10, -2, 3]\nOutput: 11"
          ],
          constraints: ["1 <= arr.length <= 1000"]
        },
        {
          title: "String Uppercase",
          description: "Write a method that converts a string to uppercase without using built-in methods.",
          examples: [
            "Input: 'hello'\nOutput: 'HELLO'",
            "Input: 'Java'\nOutput: 'JAVA'"
          ],
          constraints: ["1 <= s.length() <= 1000"]
        }
      ],
      medium: [
        {
          title: "Remove Duplicates",
          description: "Remove duplicates from a sorted array in-place and return the new length.",
          examples: [
            "Input: [1,1,2]\nOutput: 2, nums = [1,2,_]",
            "Input: [0,0,1,1,1,2,2,3,3,4]\nOutput: 5, nums = [0,1,2,3,4,_,_,_,_,_]"
          ],
          constraints: ["1 <= nums.length <= 3000"]
        },
        {
          title: "Rotate Array",
          description: "Rotate an array to the right by k steps.",
          examples: [
            "Input: nums = [1,2,3,4,5,6,7], k = 3\nOutput: [5,6,7,1,2,3,4]"
          ],
          constraints: ["1 <= nums.length <= 100000"]
        }
      ],
      hard: [
        {
          title: "Serialize Binary Tree",
          description: "Design an algorithm to serialize and deserialize a binary tree.",
          examples: [
            "Input: [1,2,3,null,null,4,5]\nOutput: '1,2,3,null,null,4,5'"
          ],
          constraints: ["Number of nodes is in range [0, 1000]"]
        },
        {
          title: "LRU Cache",
          description: "Design and implement a data structure for Least Recently Used (LRU) cache.",
          examples: [
            "LRUCache cache = new LRUCache(2);\ncache.put(1, 1); cache.put(2, 2); cache.get(1); // returns 1"
          ],
          constraints: ["1 <= capacity <= 3000"]
        }
      ]
    }
  };

  // Default to JavaScript if language not found
  return questionBank[language as keyof typeof questionBank] || questionBank.javascript;
}

/**
 * Score coding solution with AI evaluation
 */
export function scoreCodingSolution(
  question: Question,
  code: string
): { score: number; feedback: string } {
  const codeLength = code.trim().length;

  if (codeLength === 0) {
    return {
      score: 0,
      feedback: "No code solution provided."
    };
  }

  // Analyze code quality
  const codeAnalysis = analyzeCodingAnswer(question, code);
  let score = 0;

  // Base scoring on code structure and approach
  if (question.difficulty === Difficulty.EASY) {
    if (codeAnalysis.hasValidSyntax && codeAnalysis.hasCorrectApproach) {
      score = 8 + codeAnalysis.qualityBonus;
    } else if (codeAnalysis.hasValidSyntax) {
      score = 5 + codeAnalysis.qualityBonus;
    } else if (codeLength > 20) {
      score = 3;
    } else {
      score = 1;
    }
  } else if (question.difficulty === Difficulty.MEDIUM) {
    if (codeAnalysis.hasValidSyntax && codeAnalysis.hasCorrectApproach && codeAnalysis.hasGoodStructure) {
      score = 8 + codeAnalysis.qualityBonus;
    } else if (codeAnalysis.hasValidSyntax && codeAnalysis.hasCorrectApproach) {
      score = 6 + codeAnalysis.qualityBonus;
    } else if (codeAnalysis.hasValidSyntax) {
      score = 4;
    } else {
      score = 2;
    }
  } else {
    // HARD
    if (codeAnalysis.hasValidSyntax && codeAnalysis.hasCorrectApproach &&
        codeAnalysis.hasGoodStructure && codeAnalysis.hasOptimization) {
      score = 9 + codeAnalysis.qualityBonus;
    } else if (codeAnalysis.hasValidSyntax && codeAnalysis.hasCorrectApproach && codeAnalysis.hasGoodStructure) {
      score = 7 + codeAnalysis.qualityBonus;
    } else if (codeAnalysis.hasValidSyntax && codeAnalysis.hasCorrectApproach) {
      score = 5;
    } else if (codeAnalysis.hasValidSyntax) {
      score = 3;
    } else {
      score = 1;
    }
  }

  score = Math.min(10, Math.max(0, Math.round(score)));

  const feedback = generateCodingFeedback(question, code, score, codeAnalysis);

  return { score, feedback };
}

/**
 * Analyze coding answer quality
 */
function analyzeCodingAnswer(question: Question, code: string) {
  const lowerCode = code.toLowerCase();

  // Check for basic syntax patterns
  const hasValidSyntax = checkBasicSyntax(code, question.language);

  // Check for correct approach based on question
  const hasCorrectApproach = checkCorrectApproach(question, code);

  // Check for good code structure
  const hasGoodStructure = checkCodeStructure(code, question.language);

  // Check for optimization patterns
  const hasOptimization = checkOptimization(code, question.difficulty);

  // Quality bonus based on best practices
  let qualityBonus = 0;
  if (hasComments(code)) qualityBonus += 0.5;
  if (hasGoodVariableNames(code)) qualityBonus += 0.5;
  if (hasErrorHandling(code)) qualityBonus += 0.5;

  return {
    hasValidSyntax,
    hasCorrectApproach,
    hasGoodStructure,
    hasOptimization,
    qualityBonus: Math.min(1, qualityBonus)
  };
}

function checkBasicSyntax(code: string, language: string): boolean {
  const patterns = {
    javascript: /function\s+\w+\(.*\)|const\s+\w+\s*=|let\s+\w+\s*=|=>/,
    python: /def\s+\w+\(.*\):|for\s+\w+\s+in|if\s+.*:/,
    java: /public\s+\w+|private\s+\w+|class\s+\w+/
  };

  const pattern = patterns[language as keyof typeof patterns];
  return pattern ? pattern.test(code) : true;
}

function checkCorrectApproach(question: Question, code: string): boolean {
  const title = question.title.toLowerCase();
  const lowerCode = code.toLowerCase();

  // Check for relevant algorithm patterns
  if (title.includes('reverse')) {
    return lowerCode.includes('reverse') || lowerCode.includes('length') || lowerCode.includes('swap');
  }
  if (title.includes('sum') || title.includes('maximum')) {
    return lowerCode.includes('for') || lowerCode.includes('while') || lowerCode.includes('map');
  }
  if (title.includes('palindrome')) {
    return lowerCode.includes('reverse') || lowerCode.includes('compare');
  }
  if (title.includes('sort') || title.includes('merge')) {
    return lowerCode.includes('sort') || lowerCode.includes('compare');
  }

  return true; // Default to true for unknown patterns
}

function checkCodeStructure(code: string, language: string): boolean {
  // Check for proper indentation and structure
  const lines = code.split('\n');
  const hasProperIndentation = lines.some(line => line.startsWith('  ') || line.startsWith('\t'));
  const hasMultipleLines = lines.length > 3;

  return hasProperIndentation && hasMultipleLines;
}

function checkOptimization(code: string, difficulty: Difficulty): boolean {
  if (difficulty === Difficulty.EASY) return true;

  const lowerCode = code.toLowerCase();
  // Look for optimization patterns
  return lowerCode.includes('time complexity') ||
         lowerCode.includes('space complexity') ||
         lowerCode.includes('efficient') ||
         lowerCode.includes('optimize');
}

function hasComments(code: string): boolean {
  return code.includes('//') || code.includes('#') || code.includes('/*');
}

function hasGoodVariableNames(code: string): boolean {
  // Check for meaningful variable names (more than single letters)
  const meaningfulVars = /\b[a-zA-Z][a-zA-Z0-9]{2,}\b/g;
  const matches = code.match(meaningfulVars);
  return matches && matches.length > 0;
}

function hasErrorHandling(code: string): boolean {
  const lowerCode = code.toLowerCase();
  return lowerCode.includes('try') || lowerCode.includes('catch') ||
         lowerCode.includes('except') || lowerCode.includes('if');
}

/**
 * Generate coding-specific feedback based on solution quality
 */
function generateCodingFeedback(
  question: Question,
  code: string,
  score: number,
  analysis: any
): string {
  const codeLength = code.trim().length;

  if (score >= 9) {
    return "Excellent solution! Your code demonstrates strong problem-solving skills, proper syntax, and good optimization. Well done!";
  } else if (score >= 7) {
    return "Great solution! Your approach is correct and the code structure is good. Consider adding comments for better readability.";
  } else if (score >= 5) {
    return "Good attempt! Your solution shows understanding of the problem. You could improve code structure and consider edge cases.";
  } else if (score >= 3) {
    return "Your solution shows some understanding, but there are issues with the approach or syntax. Review the problem requirements.";
  } else if (codeLength > 0) {
    return "Your code needs significant improvement. Check for syntax errors and ensure your approach matches the problem requirements.";
  } else {
    return "No code solution provided. This significantly impacts your score for this question.";
  }
}

/**
 * Calculate final interview score
 */
export function calculateFinalScore(answers: Answer[]): number {
  if (answers.length === 0) return 0;

  const totalScore = answers.reduce((sum, answer) => sum + answer.score, 0);
  const averageScore = totalScore / answers.length;

  // Weight by difficulty
  let weightedScore = 0;
  let totalWeight = 0;

  answers.forEach((answer) => {
    let weight = 1;
    if (answer.difficulty === Difficulty.MEDIUM) weight = 1.2;
    if (answer.difficulty === Difficulty.HARD) weight = 1.5;

    weightedScore += answer.score * weight;
    totalWeight += weight;
  });

  return Math.round((weightedScore / totalWeight) * 10) / 10;
}

/**
 * Generate AI summary of candidate's interview performance
 */
export function generateInterviewSummary(
  candidateName: string,
  answers: Answer[],
  finalScore: number
): string {
  const easyAnswers = answers.filter((a) => a.difficulty === Difficulty.EASY);
  const mediumAnswers = answers.filter((a) => a.difficulty === Difficulty.MEDIUM);
  const hardAnswers = answers.filter((a) => a.difficulty === Difficulty.HARD);

  const easyAvg =
    easyAnswers.length > 0
      ? Math.round(
          (easyAnswers.reduce((sum, a) => sum + a.score, 0) /
            easyAnswers.length) *
            10
        ) / 10
      : 0;
  const mediumAvg =
    mediumAnswers.length > 0
      ? Math.round(
          (mediumAnswers.reduce((sum, a) => sum + a.score, 0) /
            mediumAnswers.length) *
            10
        ) / 10
      : 0;
  const hardAvg =
    hardAnswers.length > 0
      ? Math.round(
          (hardAnswers.reduce((sum, a) => sum + a.score, 0) /
            hardAnswers.length) *
            10
        ) / 10
      : 0;

  const strengths: string[] = [];
  const weaknesses: string[] = [];

  if (easyAvg >= 8) strengths.push("strong fundamentals");
  else if (easyAvg < 5) weaknesses.push("needs review of basic concepts");

  if (mediumAvg >= 8) strengths.push("solid mid-level understanding");
  else if (mediumAvg < 5) weaknesses.push("intermediate topics need improvement");

  if (hardAvg >= 8) strengths.push("excellent advanced knowledge");
  else if (hardAvg < 5) weaknesses.push("advanced concepts need development");

  let summary = `${candidateName} completed the interview with a final score of ${finalScore}/10. `;

  if (strengths.length > 0) {
    summary += `Strengths: ${strengths.join(", ")}. `;
  }

  if (weaknesses.length > 0) {
    summary += `Areas for improvement: ${weaknesses.join(", ")}. `;
  }

  if (finalScore >= 8) {
    summary +=
      "This candidate shows excellent potential for the Full Stack position.";
  } else if (finalScore >= 6) {
    summary +=
      "This candidate has good potential and would be a solid hire with some additional training.";
  } else if (finalScore >= 4) {
    summary +=
      "This candidate shows basic competency but would need significant training.";
  } else {
    summary += "This candidate may not be the best fit for this position.";
  }

  return summary;
}
