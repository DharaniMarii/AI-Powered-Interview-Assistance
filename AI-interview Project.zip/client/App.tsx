import "./global.css";

import { useState, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Interviewee from "./pages/Interviewee";
import Interviewer from "./pages/Interviewer";
import Header from "./components/Header";
import WelcomeBackModal from "./components/WelcomeBackModal";
import { useInterviewState } from "./hooks/useInterviewState";

const queryClient = new QueryClient();

type Tab = "interviewee" | "interviewer";

function AppContent() {
  const [activeTab, setActiveTab] = useState<Tab>("interviewee");
  const [showWelcomeBack, setShowWelcomeBack] = useState(false);
  const [unfinishedSessionId, setUnfinishedSessionId] = useState<string>("");
  const { getUnfinishedSessions, loadSession } = useInterviewState();

  useEffect(() => {
    const unfinished = getUnfinishedSessions();
    if (unfinished.length > 0 && !localStorage.getItem("welcomed_back")) {
      setShowWelcomeBack(true);
      setUnfinishedSessionId(unfinished[0].id);
    }
  }, [getUnfinishedSessions]);

  const handleResumeSession = () => {
    loadSession(unfinishedSessionId);
    setShowWelcomeBack(false);
    localStorage.setItem("welcomed_back", "true");
    setActiveTab("interviewee");
  };

  const handleStartNew = () => {
    setShowWelcomeBack(false);
    localStorage.setItem("welcomed_back", "true");
  };

  return (
    <div className="min-h-screen bg-background">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="pt-16">
        {activeTab === "interviewee" ? <Interviewee /> : <Interviewer />}
      </main>

      {showWelcomeBack && (
        <WelcomeBackModal
          onResume={handleResumeSession}
          onStartNew={handleStartNew}
        />
      )}
    </div>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AppContent />
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
