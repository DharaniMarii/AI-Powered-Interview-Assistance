import { useState, useEffect, useCallback } from "react";
import {
  Candidate,
  InterviewSession,
  ChatMessage,
  Answer,
  Question,
} from "@shared/api";
import { useLocalStorage } from "./useLocalStorage";
import {
  generateCodingQuestions,
  scoreCodingSolution,
  calculateFinalScore,
  generateInterviewSummary,
} from "@/lib/interviewUtils";

const CANDIDATES_STORAGE_KEY = "crisp_candidates";
const SESSIONS_STORAGE_KEY = "crisp_sessions";

export function useInterviewState() {
  const [candidates, setCandidates] = useLocalStorage<Candidate[]>(
    CANDIDATES_STORAGE_KEY,
    []
  );
  const [sessions, setSessions] = useLocalStorage<InterviewSession[]>(
    SESSIONS_STORAGE_KEY,
    []
  );
  const [currentSessionId, setCurrentSessionId] = useState<string>("");

  const currentSession = sessions.find((s) => s.id === currentSessionId);
  const currentCandidate = candidates.find(
    (c) => c.id === currentSession?.candidateId
  );

  // Create a new candidate
  const addCandidate = useCallback(
    (candidate: Candidate) => {
      setCandidates([...candidates, candidate]);
      return candidate.id;
    },
    [candidates, setCandidates]
  );

  // Update candidate
  const updateCandidate = useCallback(
    (id: string, updates: Partial<Candidate>) => {
      setCandidates(
        candidates.map((c) => (c.id === id ? { ...c, ...updates } : c))
      );
    },
    [candidates, setCandidates]
  );

  // Create a new interview session
  const createSession = useCallback(
    (candidateId: string) => {
      const questions = generateInterviewQuestions();
      const session: InterviewSession = {
        id: `session_${Date.now()}`,
        candidateId,
        startedAt: Date.now(),
        currentQuestionIndex: 0,
        questions,
        answers: [],
        chatHistory: [],
        isPaused: false,
        totalScore: 0,
        summary: "",
      };
      setSessions([...sessions, session]);
      setCurrentSessionId(session.id);
      return session.id;
    },
    [sessions, setSessions]
  );

  // Update session
  const updateSession = useCallback(
    (updates: Partial<InterviewSession>) => {
      if (!currentSessionId) return;
      setSessions(
        sessions.map((s) =>
          s.id === currentSessionId ? { ...s, ...updates } : s
        )
      );
    },
    [currentSessionId, sessions, setSessions]
  );

  // Add chat message
  const addChatMessage = useCallback(
    (message: ChatMessage) => {
      if (!currentSessionId) return;
      updateSession({
        chatHistory: [...(currentSession?.chatHistory || []), message],
      });
    },
    [currentSessionId, currentSession, updateSession]
  );

  // Submit answer for current question
  const submitAnswer = useCallback(
    (answerText: string) => {
      if (!currentSession) return;

      const currentQuestion = currentSession.questions[
        currentSession.currentQuestionIndex
      ] as Question;
      if (!currentQuestion) return;

      const { score, feedback } = scoreAnswer(currentQuestion, answerText);

      const answer: Answer = {
        questionId: currentQuestion.id,
        questionNumber: currentQuestion.number,
        text: answerText,
        difficulty: currentQuestion.difficulty,
        timeLimit: currentQuestion.timeLimit,
        timeTaken: currentQuestion.timeLimit, // Will be updated by timer
        score,
        feedback,
      };

      const newAnswers = [...currentSession.answers, answer];
      const nextQuestionIndex = currentSession.currentQuestionIndex + 1;

      // Add assistant response to chat
      const assistantMessage: ChatMessage = {
        id: `msg_${Date.now()}`,
        role: "assistant",
        content: feedback,
        timestamp: Date.now(),
        type: "result",
      };

      updateSession({
        answers: newAnswers,
        currentQuestionIndex: nextQuestionIndex,
        chatHistory: [...currentSession.chatHistory, assistantMessage],
      });

      return { score, feedback };
    },
    [currentSession, updateSession]
  );

  // Complete interview
  const completeInterview = useCallback(() => {
    if (!currentSession || !currentCandidate) return;

    const finalScore = calculateFinalScore(currentSession.answers);
    const summary = generateInterviewSummary(
      currentCandidate.resumeData.name,
      currentSession.answers,
      finalScore
    );

    // Update session
    updateSession({
      completedAt: Date.now(),
      totalScore: finalScore,
      summary,
    });

    // Update candidate
    updateCandidate(currentCandidate.id, {
      interviewCompleted: true,
      finalScore,
      summary,
    });

    return { finalScore, summary };
  }, [currentSession, currentCandidate, updateSession, updateCandidate]);

  // Pause/Resume session
  const pauseSession = useCallback(() => {
    if (!currentSession) return;
    updateSession({
      isPaused: true,
      pausedAt: Date.now(),
    });
  }, [currentSession, updateSession]);

  const resumeSession = useCallback(() => {
    if (!currentSession) return;
    updateSession({
      isPaused: false,
      resumedAt: Date.now(),
    });
  }, [currentSession, updateSession]);

  // Get unfinished sessions
  const getUnfinishedSessions = useCallback(() => {
    return sessions.filter((s) => !s.completedAt);
  }, [sessions]);

  // Load session
  const loadSession = useCallback((sessionId: string) => {
    setCurrentSessionId(sessionId);
  }, []);

  // Update answer timing
  const updateAnswerTiming = useCallback(
    (timeTaken: number) => {
      if (!currentSession || currentSession.answers.length === 0) return;

      const lastAnswerIndex = currentSession.answers.length - 1;
      const updatedAnswers = [...currentSession.answers];
      updatedAnswers[lastAnswerIndex].timeTaken = timeTaken;

      updateSession({
        answers: updatedAnswers,
      });
    },
    [currentSession, updateSession]
  );

  return {
    candidates,
    sessions,
    currentSession,
    currentCandidate,
    currentSessionId,
    addCandidate,
    updateCandidate,
    createSession,
    updateSession,
    addChatMessage,
    submitAnswer,
    completeInterview,
    pauseSession,
    resumeSession,
    getUnfinishedSessions,
    loadSession,
    updateAnswerTiming,
  };
}
