import { useState, useEffect } from "react";
import ResumeUpload from "@/components/ResumeUpload";
import MissingFieldsForm from "@/components/MissingFieldsForm";
import InterviewChat from "@/components/InterviewChat";
import InterviewResults from "@/components/InterviewResults";
import { ResumeData } from "@shared/api";
import { useInterviewState } from "@/hooks/useInterviewState";

type IntervieweePage = "upload" | "fields" | "interview" | "results";

export default function Interviewee() {
  const [currentPage, setCurrentPage] = useState<IntervieweePage>("upload");
  const [resumeData, setResumeData] = useState<ResumeData | null>(null);
  const { currentSession, currentCandidate } = useInterviewState();

  // Check if there's an active session on mount
  useEffect(() => {
    if (currentSession && currentCandidate) {
      setResumeData(currentCandidate.resumeData);

      // Determine which page to show based on session state
      if (currentSession.completedAt) {
        setCurrentPage("results");
      } else if (currentSession.currentQuestionIndex > 0 || currentSession.answers.length > 0) {
        setCurrentPage("interview");
      } else {
        setCurrentPage("interview");
      }
    }
  }, [currentSession, currentCandidate]);

  const handleResumeData = (data: ResumeData) => {
    setResumeData(data);
    setCurrentPage("fields");
  };

  const handleFieldsComplete = (data: ResumeData) => {
    setResumeData(data);
    setCurrentPage("interview");
  };

  const handleInterviewComplete = () => {
    setCurrentPage("results");
  };

  return (
    <div className="min-h-screen bg-background">
      {currentPage === "upload" && !currentSession && (
        <ResumeUpload onComplete={handleResumeData} />
      )}
      {currentPage === "fields" && resumeData && (
        <MissingFieldsForm
          resumeData={resumeData}
          onComplete={handleFieldsComplete}
        />
      )}
      {currentPage === "interview" && resumeData && (
        <InterviewChat
          resumeData={resumeData}
          onComplete={handleInterviewComplete}
        />
      )}
      {currentPage === "results" && resumeData && (
        <InterviewResults resumeData={resumeData} />
      )}
    </div>
  );
}
