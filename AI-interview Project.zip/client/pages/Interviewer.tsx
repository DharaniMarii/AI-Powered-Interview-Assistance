import { useState } from "react";
import CandidateList from "@/components/CandidateList";
import CandidateDetail from "@/components/CandidateDetail";
import { Candidate } from "@shared/api";

type InterviewerView = "list" | "detail";

export default function Interviewer() {
  const [currentView, setCurrentView] = useState<InterviewerView>("list");
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(
    null
  );

  const handleSelectCandidate = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setCurrentView("detail");
  };

  const handleBackToList = () => {
    setCurrentView("list");
    setSelectedCandidate(null);
  };

  return (
    <div className="min-h-screen bg-background">
      {currentView === "list" ? (
        <CandidateList onSelectCandidate={handleSelectCandidate} />
      ) : (
        <CandidateDetail
          candidate={selectedCandidate!}
          onBack={handleBackToList}
        />
      )}
    </div>
  );
}
