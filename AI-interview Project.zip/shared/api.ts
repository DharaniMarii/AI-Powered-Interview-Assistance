/**
 * Shared code between client and server
 * Useful to share types between client and server
 */

// Resume and Candidate Data
export interface ResumeData {
  name: string;
  email: string;
  phone: string;
  rawText?: string;
  detectedLanguages?: string[];
  selectedLanguage?: string;
}

export interface Candidate {
  id: string;
  resumeData: ResumeData;
  resumeFile?: File | null;
  createdAt: number;
  interviewCompleted: boolean;
  finalScore: number;
  summary: string;
}

// Interview Flow
export enum Difficulty {
  EASY = "easy",
  MEDIUM = "medium",
  HARD = "hard",
}

export interface Question {
  id: string;
  number: number;
  difficulty: Difficulty;
  title: string;
  description: string;
  examples: string[];
  constraints?: string[];
  timeLimit: number; // in seconds
  language: string;
}

export interface Answer {
  questionId: string;
  questionNumber: number;
  text: string;
  difficulty: Difficulty;
  timeLimit: number;
  timeTaken: number; // in seconds
  score: number; // 0-10
  feedback: string;
}

export interface ChatMessage {
  id: string;
  role: "assistant" | "user";
  content: string;
  timestamp: number;
  type?: "text" | "question" | "timer" | "result";
}

export interface InterviewSession {
  id: string;
  candidateId: string;
  startedAt: number;
  pausedAt?: number;
  resumedAt?: number;
  completedAt?: number;
  currentQuestionIndex: number;
  questions: Question[];
  answers: Answer[];
  chatHistory: ChatMessage[];
  isPaused: boolean;
  totalScore: number;
  summary: string;
}

// Example response type
export interface DemoResponse {
  message: string;
}
